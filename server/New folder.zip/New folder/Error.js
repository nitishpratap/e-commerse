import React from "react";
const Error = ()=>{
    return (<>
        <h1 style={{color:'red'}}>404 page not found try something else</h1>
    </>)
}
export default Error;