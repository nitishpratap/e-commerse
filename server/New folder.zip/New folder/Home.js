import React, { useEffect } from "react";
import { Card, Button } from "react-bootstrap";
import arr from "../Products/Items";
import imageUrl from '../Products/productImage'
import axios from "axios";
import { useState } from "react";
function Home() {
  // console.log(arr);
  const [finalProductArr,handleProduct] = useState([])

  
  const allHandler = async(e)=>{
    
    console.log(e.target.value)
    try {
      const res = await axios.get(`/${e.target.value}`)
    const productList = res.data
    console.log(productList[0].name);
    handleProduct(productList)
    
      
    } catch (error) {
      
    }
  }


  const electHandler = async(e)=>{
    
    // console.log(e.target.value)
    try {
      const res = await axios.get(`/${e.target.value}`)
    const productList = res.data
    console.log(productList[0].name);
    handleProduct(productList)
    
      
    } catch (error) {
      
    }
  }


  const assoceriesHandler = async(e)=>{
    
    // console.log(e.target.value)
    try {
      const res = await axios.get(`/${e.target.value}`)
    const productList = res.data
    console.log(productList[0].name);
    handleProduct(productList)
    
      
    } catch (error) {
      
    }
  }

  const bookHandler = async(e)=>{
    
    console.log(e.target.value)
    try {
      const res = await axios.get(`/${e.target.value}`)
    const productList = res.data
    console.log(productList[0].name);
    handleProduct(productList)
    
      
    } catch (error) {
      
    }
  }

  const clothHandler = async(e)=>{
    
    console.log(e.target.value)
    try {
      const res = await axios.get(`/${e.target.value}`)
    const productList = res.data
    console.log(productList[0].name);
    handleProduct(productList)
    
      
    } catch (error) {
      
    }
  }  


  const getAllProducts = async()=>{
    try {
      // const res = await fetch('/get',{
      //   method:'GET',
      //   headers:{
      //     'Content-Type':'application/json'
      // }
        
        
       
    // });
    const res = await axios.get('/get')
    const productList = res.data
    console.log(productList[0].name);
    handleProduct(productList)
     

    } catch (error) {
      console.log(error)
    }
  }

  useEffect(()=>{
     getAllProducts();
    console.log(finalProductArr);

  },[])





  return (
    <>
    <div style={{display:'flex',margin:'1rem', justifyContent:'space-evenly', color:'blue'}}>
    <h4><input type='checkbox' value='get' onClick={allHandler}/>All</h4>
    <h4><input type='checkbox' value='electronics' onClick={electHandler}/>Electronics</h4>
   <h4> <input type='checkbox' value='book' onClick={bookHandler}/>Book</h4>
    <h4> <input type='checkbox' value='clothing' onClick={clothHandler}/>Cloths</h4>
   <h4> <input type='checkbox' value='assesories' onClick={assoceriesHandler}/>Assoceries</h4>
    </div>



     <div  style={{display:'flex',flexWrap:'wrap',justifyContent:'space-between',padding:'2rem'}}>
      {finalProductArr.map((e) => {
        return(

       

        <div className="product" style={{margin:'1rem'}}>
        <Card style={{ width: "18rem",display:'flex'}}>
          <Card.Img variant="top" src={imageUrl} />
          <Card.Body>
            <Card.Title>{e.name}</Card.Title>
            <Card.Text>
             {e.description}
            </Card.Text>
            <Card.Text>
             Price {e.price}
            </Card.Text>
            <Button variant="primary" style={{marginRight:'4rem'}}>Buy now</Button>
            <Button variant="primary">Add to cart</Button>
          </Card.Body>
        </Card>
        
      </div>
      

        )


      })}
      </div>

    </>
  );
}
export default Home;
